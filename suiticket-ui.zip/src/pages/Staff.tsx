import { useEffect, useMemo, useState } from "react";
import { Button, Card, Flex, Text, TextField } from "@radix-ui/themes";
import {
  useCurrentAccount,
  useSignAndExecuteTransaction,
  useSuiClient,
} from "@mysten/dapp-kit";
import { Transaction } from "@mysten/sui/transactions";

import PageHeader from "../components/PageHeader";
import EmptyState from "../components/EmptyState";
import QrScanModal from "../components/QrScanModal";
import { copyText, readText } from "../lib/clipboard";
import { CURRENT_PACKAGE_ID, TARGETS } from "../config/contracts";

type Lookup = {
  ok: boolean;
  reason?: string;
  owner?: string;
  used?: boolean;
  type?: string;
  eventId?: string;
};

type CapRow = { id: string; eventId?: string };

function isAddressOwner(owner: any): owner is { AddressOwner: string } {
  return owner && typeof owner === "object" && "AddressOwner" in owner;
}

function shortId(id?: string) {
  if (!id) return "-";
  const s = id.trim();
  if (s.length <= 14) return s;
  return `${s.slice(0, 6)}…${s.slice(-4)}`;
}

export default function Staff() {
  const account = useCurrentAccount();
  const client = useSuiClient();

  const [capId, setCapId] = useState("");
  const [ticketId, setTicketId] = useState("");
  const [lookup, setLookup] = useState<Lookup | null>(null);

  const [status, setStatus] = useState<string>("");
  const [permitId, setPermitId] = useState<string>("");
  const [lastDigest, setLastDigest] = useState<string>("");

  const [caps, setCaps] = useState<CapRow[]>([]);
  const [scanOpen, setScanOpen] = useState(false);

  const pkgPrefix = useMemo(() => `${CURRENT_PACKAGE_ID}::ticket::`, []);
  const { mutate: signAndExecute, isPending } = useSignAndExecuteTransaction();

  async function waitTx(digest: string) {
    const txb = await (client as any).waitForTransactionBlock?.({
      digest,
      options: { showEffects: true, showObjectChanges: true },
    });
    if (txb) return txb;

    for (let i = 0; i < 25; i++) {
      try {
        const t = await client.getTransactionBlock({
          digest,
          options: { showEffects: true, showObjectChanges: true },
        });
        const s = (t as any)?.effects?.status?.status;
        if (s) return t;
      } catch {}
      await new Promise((r) => setTimeout(r, 250 + i * 50));
    }
    throw new Error("Timed out waiting for transaction result.");
  }

  async function refreshCaps() {
    if (!account?.address) return;

    const all: any[] = [];
    let cursor: string | null | undefined = null;

    while (true) {
      const page = await client.getOwnedObjects({
        owner: account.address,
        cursor,
        limit: 50,
        options: { showType: true, showContent: true },
      });

      all.push(...(page.data ?? []));
      if (!page.hasNextPage) break;
      cursor = page.nextCursor;
    }

    const out: CapRow[] = [];
    for (const it of all) {
      const id = (it.data as any)?.objectId as string | undefined;
      const type = (it.data as any)?.type as string | undefined;
      if (!id || !type) continue;
      if (!type.startsWith(pkgPrefix) || !type.endsWith("::GateCap")) continue;

      const fields = (it.data as any)?.content?.fields;
      const eventId = fields?.event_id ? String(fields.event_id) : undefined;
      out.push({ id, eventId });
    }

    setCaps(out);
    if (!capId && out[0]?.id) setCapId(out[0].id);
  }

  useEffect(() => {
    refreshCaps().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [account?.address]);

  function onScanned(text: string) {
    const clean = text.trim();
    const id = clean.startsWith("ticket:")
      ? clean.slice("ticket:".length)
      : clean;

    setTicketId(id.trim());
    setLookup(null);
    setPermitId("");
    setLastDigest("");
    setStatus("✅ Scanned. Click Lookup.");
  }

  async function onLookup() {
    const id = ticketId.trim();
    if (!id) return;

    setStatus("Looking up ticket...");
    setPermitId("");
    setLastDigest("");
    setLookup(null);

    try {
      const obj = await client.getObject({
        id,
        options: { showType: true, showOwner: true, showContent: true },
      });

      const type = (obj as any)?.data?.type as string | undefined;
      const owner = (obj as any)?.data?.owner;
      const fields = (obj as any)?.data?.content?.fields;

      if (!type || !type.startsWith(pkgPrefix) || !type.endsWith("::Ticket")) {
        setLookup({
          ok: false,
          reason: `Not a Ticket from the CURRENT package. Got type=${type ?? "(none)"}`,
          type: type ?? "(none)",
        });
        setStatus("❌ This is not a Ticket from the CURRENT package.");
        return;
      }

      if (!isAddressOwner(owner)) {
        setLookup({ ok: false, reason: "Ticket is not AddressOwner." });
        setStatus("❌ Ticket owner is not an address (unexpected).");
        return;
      }

      const used = fields?.used;
      const eventId = fields?.event_id ? String(fields.event_id) : undefined;

      setLookup({
        ok: true,
        owner: owner.AddressOwner,
        used: typeof used === "boolean" ? used : undefined,
        eventId,
        type,
      });

      setStatus("✅ Lookup OK. You can issue a permit.");
    } catch (e: any) {
      setLookup({ ok: false, reason: e?.message ?? String(e) });
      setStatus(`❌ Lookup failed: ${e?.message ?? String(e)}`);
    }
  }

  function extractCreatedPermitId(objectChanges: any[]): string {
    const hit = (objectChanges ?? []).find(
      (c) =>
        c.type === "created" &&
        typeof c.objectType === "string" &&
        c.objectType.endsWith("::RedeemPermit"),
    );
    return hit?.objectId ?? "";
  }

  function onIssuePermit() {
    if (!account?.address) return setStatus("Please connect staff wallet.");
    if (!capId.trim() || !ticketId.trim())
      return setStatus("Fill GateCap ID + Ticket ID.");
    if (!lookup?.ok || !lookup.owner)
      return setStatus("Run lookup first (need ticket owner).");
    if (lookup.used)
      return setStatus("Ticket already used — do not issue permit.");

    setStatus("Issuing permit...");
    setPermitId("");
    setLastDigest("");

    const tx = new Transaction();
    tx.setGasBudget(30_000_000);

    tx.moveCall({
      target: TARGETS.issuePermit,
      arguments: [
        tx.object(capId.trim()),
        tx.pure.address(ticketId.trim()),
        tx.pure.address(lookup.owner),
      ],
    });

    signAndExecute(
      { transaction: tx, chain: "sui:testnet" },
      {
        onSuccess: async (res) => {
          setLastDigest(res.digest);

          try {
            const txb = await waitTx(res.digest);
            const changes = ((txb as any)?.objectChanges ?? []) as any[];
            const pid = extractCreatedPermitId(changes);
            if (pid) setPermitId(pid);
            setStatus("✅ Permit issued.");
          } catch (e: any) {
            setStatus(
              `✅ Permit issued, but couldn't load object changes: ${
                e?.message ?? String(e)
              }`,
            );
          }
        },
        onError: (err) => setStatus(`❌ issue_permit failed: ${String(err)}`),
      },
    );
  }

  async function onPasteTicketId() {
    const t = await readText();
    if (!t) return setStatus("Clipboard is empty / not permitted.");
    setTicketId(t.trim());
    setLookup(null);
    setPermitId("");
    setLastDigest("");
    setStatus("✅ Pasted from clipboard. Click Lookup.");
  }

  return (
    <>
      <QrScanModal
        open={scanOpen}
        onClose={() => setScanOpen(false)}
        onScan={onScanned}
        title="Scan attendee QR"
        hint="Point camera at attendee's ticket QR. We'll fill Ticket ID."
      />

      <Flex direction="column" gap="4">
        <PageHeader
          title="Staff"
          subtitle="Pick a GateCap, scan/paste ticket ID, lookup, then issue a one-time permit."
          right={
            <Button
              size="2"
              variant="soft"
              onClick={() => refreshCaps()}
              disabled={!account?.address || isPending}
            >
              Refresh
            </Button>
          }
        />

        <Card>
          <Flex direction="column" gap="3">
            <Text weight="medium">Your GateCaps</Text>

            {caps.length === 0 ? (
              <EmptyState
                title="No GateCap found"
                desc="Connect the staff wallet that holds the GateCap."
              />
            ) : (
              <Flex direction="column" gap="2">
                {caps.map((c) => (
                  <Card key={c.id}>
                    <Flex align="center" justify="between" gap="3" wrap="wrap">
                      <Flex
                        direction="column"
                        gap="1"
                        style={{ minWidth: 260 }}
                      >
                        <Text
                          size="2"
                          style={{ wordBreak: "break-all", opacity: 0.85 }}
                        >
                          Cap: {shortId(c.id)}
                        </Text>
                        <Text
                          size="2"
                          style={{ wordBreak: "break-all", opacity: 0.7 }}
                        >
                          Event: {shortId(c.eventId)}
                        </Text>
                      </Flex>

                      <Flex gap="2" wrap="wrap">
                        <Button
                          size="2"
                          variant={capId === c.id ? "solid" : "soft"}
                          onClick={() => setCapId(c.id)}
                        >
                          {capId === c.id ? "Using" : "Use"}
                        </Button>

                        <Button
                          size="2"
                          variant="soft"
                          color="gray"
                          onClick={() => copyText(c.id)}
                        >
                          Copy
                        </Button>
                      </Flex>
                    </Flex>
                  </Card>
                ))}
              </Flex>
            )}
          </Flex>
        </Card>

        <Card>
          <Flex direction="column" gap="3">
            <Text weight="medium">Issue permit</Text>

            <Flex direction="column" gap="2">
              <Text size="2" color="gray">
                GateCap
              </Text>
              <Flex gap="2" wrap="wrap" align="center">
                <TextField.Root
                  placeholder="0x... GateCap object id"
                  value={capId}
                  onChange={(e) => setCapId(e.target.value)}
                  style={{ flex: 1, minWidth: 320 }}
                />
                <Button
                  size="2"
                  variant="soft"
                  color="gray"
                  disabled={!capId.trim()}
                  onClick={() => copyText(capId.trim())}
                >
                  Copy
                </Button>
              </Flex>
            </Flex>

            <Flex direction="column" gap="2">
              <Text size="2" color="gray">
                Ticket ID
              </Text>
              <Flex gap="2" wrap="wrap" align="center">
                <TextField.Root
                  placeholder="0x... Ticket object id"
                  value={ticketId}
                  onChange={(e) => setTicketId(e.target.value)}
                  style={{ flex: 1, minWidth: 320 }}
                />

                <Button
                  size="2"
                  variant="soft"
                  onClick={() => setScanOpen(true)}
                  disabled={isPending}
                >
                  Scan QR
                </Button>

                <Button
                  size="2"
                  variant="soft"
                  color="gray"
                  onClick={onPasteTicketId}
                  disabled={isPending}
                >
                  Paste
                </Button>

                <Button
                  size="2"
                  variant="soft"
                  color="gray"
                  onClick={() => copyText(ticketId.trim())}
                  disabled={!ticketId.trim()}
                >
                  Copy
                </Button>
              </Flex>
            </Flex>

            <Flex gap="2" wrap="wrap" align="center">
              <Button
                size="2"
                variant="soft"
                onClick={onLookup}
                disabled={isPending || !ticketId.trim()}
              >
                Lookup
              </Button>
              <Button
                size="2"
                onClick={onIssuePermit}
                disabled={isPending || !lookup?.ok || !capId.trim()}
              >
                Issue Permit
              </Button>
            </Flex>

            {status ? (
              <Text size="2" style={{ whiteSpace: "pre-wrap", opacity: 0.85 }}>
                {status}
              </Text>
            ) : null}
          </Flex>
        </Card>

        <Flex direction="column" gap="2">
          <Text weight="medium">Result</Text>

          {!lookup ? (
            <EmptyState
              title="No lookup yet"
              desc="Lookup a ticket to see owner + used status here."
            />
          ) : (
            <Card>
              <Flex direction="column" gap="2">
                <Text size="2" color="gray">
                  Ticket info
                </Text>

                <Text style={{ wordBreak: "break-all", opacity: 0.85 }}>
                  <Text weight="medium">Owner:</Text> {lookup.owner ?? "-"}{" "}
                  {lookup.owner ? (
                    <Button
                      size="1"
                      variant="soft"
                      color="gray"
                      style={{ marginLeft: 8 }}
                      onClick={() => copyText(lookup.owner!)}
                    >
                      Copy
                    </Button>
                  ) : null}
                </Text>

                <Text style={{ opacity: 0.85 }}>
                  <Text weight="medium">Used:</Text>{" "}
                  {String(lookup.used ?? false)}
                </Text>

                <Text size="2" style={{ opacity: 0.7 }}>
                  Event: {shortId(lookup.eventId)}
                </Text>

                {permitId ? (
                  <>
                    <Text size="2" color="gray" style={{ marginTop: 8 }}>
                      Permit created
                    </Text>
                    <Text style={{ wordBreak: "break-all", opacity: 0.85 }}>
                      Permit ID: {permitId}{" "}
                      <Button
                        size="1"
                        variant="soft"
                        color="gray"
                        style={{ marginLeft: 8 }}
                        onClick={() => copyText(permitId)}
                      >
                        Copy
                      </Button>
                    </Text>
                    <Text
                      size="2"
                      style={{ wordBreak: "break-all", opacity: 0.75 }}
                    >
                      Tx: {lastDigest}
                    </Text>
                  </>
                ) : null}
              </Flex>
            </Card>
          )}
        </Flex>
      </Flex>
    </>
  );
}
